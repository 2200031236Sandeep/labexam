package com.klef.jfsd.exam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    // Save a Vehicle entity
    public void saveVehicle(Vechile vehicle) {
        vehicleRepository.save(vehicle);  // Use the correct variable name 'vehicle'
    }

    // Retrieve all Vehicle entities
    public List<Vechile> getAllVehicles() {
        return vehicleRepository.findAll();
    }
}
