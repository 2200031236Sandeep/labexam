package com.klef.jfsd.exam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @PostMapping("/addCar")
    public String addCar(@RequestBody Car car) {
        vehicleService.saveCar(car);
        return "Car added successfully!";
    }
}