package com.klef.jfsd.exam;

import jakarta.persistence.*;

@Entity
@DiscriminatorValue("Car")
public class Car extends Vechile {
    @Column(name = "num_doors", nullable = false)
    private int numberOfDoors;

    
}
