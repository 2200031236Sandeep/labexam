package com.klef.jfsd.exam;

public class Truck {

}
